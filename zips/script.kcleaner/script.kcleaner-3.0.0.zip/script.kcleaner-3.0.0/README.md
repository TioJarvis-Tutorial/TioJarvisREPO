KCleaner addon


There are a few cleaning addons, but none clean everything. Some are not maintained and all functions don't work. So I ended up using 3 different cleaning addons. And then I decided to write my own, and add a few things no other cleaning addon has.

For the time being, it cleans:

* Temp/Cache
* Packages
* Thumbnails
* ATV downloaded files
* Addons

There are 9 addons which are cleaned, I tried to find ones that collect the most garbage, temporary files, or just a lot of files over time. These include some that might actually be useful like "ArtistSlideshow" that collects a lot of images. If you need these images, then don't run the Addon cleanup - but anyways they would be downloaded again, so they can be considered cache files.

If you have device that is running low on space, cleaning all the downloaded stuff and cache with a single press can be useful - and about the only option you have!
